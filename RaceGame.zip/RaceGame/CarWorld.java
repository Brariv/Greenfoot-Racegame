import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CrabWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CarWorld extends World
{
    
    public static int BothCars = 0;
    Player Players = new Player("Azul");
    Scoreboard myScoreBoard = new Scoreboard("Vueltas: ");
    Health myHealth = new Health("Vida: "+"hp");
    Player OpPlayers = new Player("Rojo");
    Scoreboard OpScoreBoard = new Scoreboard("Vueltas: ");
    Health OpHealth = new Health("Vida: "+"hp");
    /**
     * Constructor for objects of class CrabWorld.
     * 
     */
    public CarWorld()
    {    
        super(900, 900, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {

        SB sB = new SB();
        addObject(sB,467,47);
        CopyOfSB copyOfSB = new CopyOfSB();
        addObject(copyOfSB,468,92);
        Car car = new Car();
        addObject(car,410,859);
        addObject(Players,490,30);
        addObject(myScoreBoard,432,54);
        addObject(myHealth,610,54);
        addObject(OpPlayers,490,75);
        addObject(OpScoreBoard,432,100);
        addObject(OpHealth,610,100);
        Kid kid = new Kid();
        addObject(kid,657,299);
        Police police = new Police();
        addObject(police,104,404);

        car.setLocation(532,858);
        car.setLocation(507,856);
        car.setLocation(507,856);
        car.setLocation(526,856);
        car.setLocation(526,856);
        car.setLocation(526,856);
        car.setLocation(526,856);
        car.setLocation(526,856);
        car.setLocation(526,856);
        ParedH paredH = new ParedH();
        addObject(paredH,723,788);
        ParedH paredH2 = new ParedH();
        addObject(paredH2,671,788);
        paredH2.setLocation(689,788);
        ParedH paredH3 = new ParedH();
        addObject(paredH3,634,788);
        ParedH paredH4 = new ParedH();
        addObject(paredH4,583,788);
        paredH3.setLocation(643,789);
        paredH4.setLocation(605,789);
        paredH4.setLocation(600,780);
        ParedH paredH5 = new ParedH();
        addObject(paredH5,557,788);
        ParedH paredH6 = new ParedH();
        addObject(paredH6,510,788);
        ParedH paredH7 = new ParedH();
        addObject(paredH7,431,788);
        ParedH paredH8 = new ParedH();
        addObject(paredH8,395,788);
        ParedH paredH9 = new ParedH();
        addObject(paredH9,223,788);
        ParedH paredH10 = new ParedH();
        addObject(paredH10,187,788);
        ParedH paredH11 = new ParedH();
        addObject(paredH11,156,886);
        ParedH paredH12 = new ParedH();
        addObject(paredH12,186,886);
        ParedH paredH13 = new ParedH();
        addObject(paredH13,222,886);
        ParedH paredH14 = new ParedH();
        addObject(paredH14,257,886);
        ParedH paredH15 = new ParedH();
        addObject(paredH15,289,886);
        ParedH paredH16 = new ParedH();
        addObject(paredH16,323,886);
        ParedH paredH17 = new ParedH();
        addObject(paredH17,354,886);
        ParedH paredH18 = new ParedH();
        addObject(paredH18,379,886);
        ParedH paredH19 = new ParedH();
        addObject(paredH19,414,886);
        ParedH paredH20 = new ParedH();
        addObject(paredH20,511,889);
        ParedH paredH21 = new ParedH();
        addObject(paredH21,552,889);
        ParedH paredH22 = new ParedH();
        addObject(paredH22,594,889);
        ParedH paredH23 = new ParedH();
        addObject(paredH23,639,889);
        ParedH paredH24 = new ParedH();
        addObject(paredH24,679,889);
        ParedH paredH25 = new ParedH();
        addObject(paredH25,720,889);
        ParedH paredH26 = new ParedH();
        addObject(paredH26,763,889);
        paredH19.setLocation(422,885);
        paredH17.setLocation(384,885);
        paredH19.setLocation(430,885);
        paredH18.setLocation(395,885);
        paredH17.setLocation(362,885);
        paredH7.setLocation(424,785);
        paredH7.setLocation(428,785);
        paredH8.setLocation(387,784);
        paredH5.setLocation(536,788);
        paredH6.setLocation(518,784);
        paredH6.setLocation(523,785);
        paredH4.setLocation(573,788);
        paredH3.setLocation(588,782);
        paredH3.setLocation(605,787);
        paredH3.setLocation(636,786);
        paredH2.setLocation(662,783);
        paredH.setLocation(692,786);
        ParedH paredH27 = new ParedH();
        addObject(paredH27,735,786);
        ParedH paredH28 = new ParedH();
        addObject(paredH28,360,487);
        ParedH paredH29 = new ParedH();
        addObject(paredH29,400,487);
        ParedH paredH30 = new ParedH();
        addObject(paredH30,437,487);
        ParedH paredH31 = new ParedH();
        addObject(paredH31,476,487);
        ParedH paredH32 = new ParedH();
        addObject(paredH32,516,487);
        ParedH paredH33 = new ParedH();
        addObject(paredH33,553,487);
        ParedH paredH34 = new ParedH();
        addObject(paredH34,597,591);
        ParedH paredH35 = new ParedH();
        addObject(paredH35,559,591);
        ParedH paredH36 = new ParedH();
        addObject(paredH36,519,591);
        ParedH paredH37 = new ParedH();
        addObject(paredH37,479,591);
        ParedH paredH38 = new ParedH();
        addObject(paredH38,436,591);
        ParedH paredH39 = new ParedH();
        addObject(paredH39,387,591);
        paredH39.setLocation(404,583);
        paredH39.setLocation(398,583);
        ParedH paredH40 = new ParedH();
        addObject(paredH40,353,592);
        ParedH paredH41 = new ParedH();
        addObject(paredH41,196,107);
        ParedH paredH42 = new ParedH();
        addObject(paredH42,731,104);
        ParedH paredH43 = new ParedH();
        addObject(paredH43,663,15);
        ParedH paredH44 = new ParedH();
        addObject(paredH44,707,3);
        ParedH paredH45 = new ParedH();
        addObject(paredH45,762,2);
        ParedH paredH46 = new ParedH();
        addObject(paredH46,808,18);
        ParedH paredH47 = new ParedH();
        addObject(paredH47,270,15);
        ParedH paredH48 = new ParedH();
        addObject(paredH48,231,2);
        ParedH paredH49 = new ParedH();
        addObject(paredH49,154,5);
        ParedH paredH50 = new ParedH();
        addObject(paredH50,111,20);
        paredH48.setLocation(219,1);
        paredH49.setLocation(164,1);
        ParedV paredV = new ParedV();
        addObject(paredV,597,131);
        ParedV paredV2 = new ParedV();
        addObject(paredV2,597,162);
        ParedV paredV3 = new ParedV();
        addObject(paredV3,599,200);
        ParedV paredV4 = new ParedV();
        addObject(paredV4,599,237);
        ParedV paredV5 = new ParedV();
        addObject(paredV5,599,353);
        ParedV paredV6 = new ParedV();
        addObject(paredV6,599,387);
        ParedV paredV7 = new ParedV();
        addObject(paredV7,598,423);
        ParedV paredV8 = new ParedV();
        addObject(paredV8,598,460);
        paredV7.setLocation(594,417);
        paredV8.setLocation(595,441);
        ParedV paredV9 = new ParedV();
        addObject(paredV9,703,461);
        ParedV paredV10 = new ParedV();
        addObject(paredV10,703,422);
        ParedV paredV11 = new ParedV();
        addObject(paredV11,703,391);
        ParedV paredV12 = new ParedV();
        addObject(paredV12,703,349);
        ParedV paredV13 = new ParedV();
        addObject(paredV13,703,254);
        ParedV paredV14 = new ParedV();
        addObject(paredV14,703,219);
        ParedV paredV15 = new ParedV();
        addObject(paredV15,703,181);
        ParedV paredV16 = new ParedV();
        addObject(paredV16,703,146);
        ParedV paredV17 = new ParedV();
        addObject(paredV17,769,147);
        ParedV paredV18 = new ParedV();
        addObject(paredV18,769,184);
        ParedV paredV19 = new ParedV();
        addObject(paredV19,769,219);
        ParedV paredV20 = new ParedV();
        addObject(paredV20,769,257);
        ParedV paredV21 = new ParedV();
        addObject(paredV21,769,288);
        ParedV paredV22 = new ParedV();
        addObject(paredV22,769,316);
        ParedV paredV23 = new ParedV();
        addObject(paredV23,769,346);
        paredV23.setLocation(769,367);
        ParedV paredV24 = new ParedV();
        addObject(paredV24,769,367);
        ParedV paredV25 = new ParedV();
        addObject(paredV25,769,396);
        paredV24.setLocation(769,427);
        paredV25.setLocation(769,382);
        ParedV paredV26 = new ParedV();
        addObject(paredV26,769,460);
        ParedV paredV27 = new ParedV();
        addObject(paredV27,769,498);
        ParedV paredV28 = new ParedV();
        addObject(paredV28,769,534);
        ParedV paredV29 = new ParedV();
        addObject(paredV29,769,571);
        ParedV paredV30 = new ParedV();
        addObject(paredV30,769,609);
        ParedV paredV31 = new ParedV();
        addObject(paredV31,769,648);
        ParedV paredV32 = new ParedV();
        addObject(paredV32,769,686);
        ParedV paredV33 = new ParedV();
        addObject(paredV33,769,721);
        ParedV paredV34 = new ParedV();
        addObject(paredV34,769,758);
        ParedV paredV35 = new ParedV();
        addObject(paredV35,874,778);
        ParedV paredV36 = new ParedV();
        addObject(paredV36,874,740);
        ParedV paredV37 = new ParedV();
        addObject(paredV37,874,704);
        ParedV paredV38 = new ParedV();
        addObject(paredV38,874,669);
        ParedV paredV39 = new ParedV();
        addObject(paredV39,874,624);
        ParedV paredV40 = new ParedV();
        addObject(paredV40,874,577);
        paredV39.setLocation(874,622);
        paredV40.setLocation(875,587);
        ParedV paredV41 = new ParedV();
        addObject(paredV41,875,544);
        ParedV paredV42 = new ParedV();
        addObject(paredV42,875,501);
        ParedV paredV43 = new ParedV();
        addObject(paredV43,875,454);
        ParedV paredV44 = new ParedV();
        addObject(paredV44,875,410);
        ParedV paredV45 = new ParedV();
        addObject(paredV45,875,362);
        ParedV paredV46 = new ParedV();
        addObject(paredV46,875,220);
        ParedV paredV47 = new ParedV();
        addObject(paredV47,875,258);
        ParedV paredV48 = new ParedV();
        addObject(paredV48,875,291);
        ParedV paredV49 = new ParedV();
        addObject(paredV49,875,326);
        ParedV paredV50 = new ParedV();
        addObject(paredV50,875,185);
        ParedV paredV51 = new ParedV();
        addObject(paredV51,875,153);
        paredV51.setLocation(869,138);
        paredV50.setLocation(869,171);
        paredV45.setLocation(873,377);
        paredV44.setLocation(873,417);
        paredV44.setLocation(873,411);
        paredV44.setLocation(873,425);
        paredV44.setLocation(873,415);
        paredV43.setLocation(873,443);
        paredV49.setLocation(866,334);
        paredV48.setLocation(865,295);
        paredH39.setLocation(396,592);
        paredH4.setLocation(582,786);
        paredH5.setLocation(511,786);
        paredH5.setLocation(551,786);
        paredH6.setLocation(515,791);
        paredH7.setLocation(439,781);
        paredH8.setLocation(404,785);
        paredH27.setLocation(731,789);
        paredH.setLocation(679,791);
        paredH3.setLocation(619,794);
        paredH.setLocation(707,794);
        paredH2.setLocation(664,792);
        paredV23.setLocation(764,387);
        paredV23.setLocation(764,334);
        paredV45.setLocation(874,374);
        paredV49.setLocation(874,327);
        paredV48.setLocation(880,289);
        paredV50.setLocation(872,186);
        paredV51.setLocation(879,142);
        paredV48.setLocation(873,282);
        paredV43.setLocation(875,460);
        paredV38.setLocation(874,644);
        paredV36.setLocation(874,741);
        paredV35.setLocation(874,788);
        paredV51.setLocation(878,159);
        ParedV paredV52 = new ParedV();
        addObject(paredV52,334,451);
        ParedV paredV53 = new ParedV();
        addObject(paredV53,334,414);
        ParedV paredV54 = new ParedV();
        addObject(paredV54,334,373);
        ParedV paredV55 = new ParedV();
        addObject(paredV55,334,333);
        ParedV paredV56 = new ParedV();
        addObject(paredV56,333,292);
        ParedV paredV57 = new ParedV();
        addObject(paredV57,333,251);
        ParedV paredV58 = new ParedV();
        addObject(paredV58,333,209);
        ParedV paredV59 = new ParedV();
        addObject(paredV59,333,171);
        ParedV paredV60 = new ParedV();
        addObject(paredV60,333,132);
        ParedV paredV61 = new ParedV();
        addObject(paredV61,223,145);
        ParedV paredV62 = new ParedV();
        addObject(paredV62,224,184);
        ParedV paredV63 = new ParedV();
        addObject(paredV63,224,224);
        ParedV paredV64 = new ParedV();
        addObject(paredV64,224,267);
        ParedV paredV65 = new ParedV();
        addObject(paredV65,224,304);
        ParedV paredV66 = new ParedV();
        addObject(paredV66,224,346);
        ParedV paredV67 = new ParedV();
        addObject(paredV67,224,389);
        ParedV paredV68 = new ParedV();
        addObject(paredV68,224,432);
        ParedV paredV69 = new ParedV();
        addObject(paredV69,224,468);
        paredV69.setLocation(223,477);
        paredV68.setLocation(227,437);
        paredV67.setLocation(232,394);
        paredV66.setLocation(219,356);
        paredV65.setLocation(226,303);
        paredV64.setLocation(223,269);
        paredV63.setLocation(228,232);
        paredV62.setLocation(232,177);
        paredV61.setLocation(223,140);
        paredV23.setLocation(771,348);
        paredH42.setLocation(725,100);
        paredV62.setLocation(226,180);
        paredV63.setLocation(226,217);
        paredV62.setLocation(228,186);
        paredV65.setLocation(227,302);
        paredV64.setLocation(230,259);
        paredV66.setLocation(225,340);
        paredV67.setLocation(220,384);
        paredV68.setLocation(222,430);
        paredV69.setLocation(229,474);
        paredV37.setLocation(872,686);
        paredV38.setLocation(872,660);
        paredV51.setLocation(870,151);
        ParedV paredV70 = new ParedV();
        addObject(paredV70,165,145);
        ParedV paredV71 = new ParedV();
        addObject(paredV71,162,186);
        ParedV paredV72 = new ParedV();
        addObject(paredV72,162,225);
        ParedV paredV73 = new ParedV();
        addObject(paredV73,162,264);
        ParedV paredV74 = new ParedV();
        addObject(paredV74,163,302);
        ParedV paredV75 = new ParedV();
        addObject(paredV75,163,342);
        ParedV paredV76 = new ParedV();
        addObject(paredV76,163,380);
        ParedV paredV77 = new ParedV();
        addObject(paredV77,163,417);
        ParedV paredV78 = new ParedV();
        addObject(paredV78,162,456);
        ParedV paredV79 = new ParedV();
        addObject(paredV79,162,489);
        ParedV paredV80 = new ParedV();
        addObject(paredV80,162,527);
        ParedV paredV81 = new ParedV();
        addObject(paredV81,162,560);
        ParedV paredV82 = new ParedV();
        addObject(paredV82,162,693);
        ParedV paredV83 = new ParedV();
        addObject(paredV83,159,730);
        ParedV paredV84 = new ParedV();
        addObject(paredV84,165,761);
        ParedV paredV85 = new ParedV();
        addObject(paredV85,58,765);
        ParedV paredV86 = new ParedV();
        addObject(paredV86,56,724);
        ParedV paredV87 = new ParedV();
        addObject(paredV87,56,678);
        ParedV paredV88 = new ParedV();
        addObject(paredV88,56,634);
        ParedV paredV89 = new ParedV();
        addObject(paredV89,56,594);
        ParedV paredV90 = new ParedV();
        addObject(paredV90,56,554);
        ParedV paredV91 = new ParedV();
        addObject(paredV91,56,517);
        ParedV paredV92 = new ParedV();
        addObject(paredV92,56,471);
        ParedV paredV93 = new ParedV();
        addObject(paredV93,56,426);
        ParedV paredV94 = new ParedV();
        addObject(paredV94,56,388);
        ParedV paredV95 = new ParedV();
        addObject(paredV95,56,346);
        ParedV paredV96 = new ParedV();
        addObject(paredV96,56,301);
        ParedV paredV97 = new ParedV();
        addObject(paredV97,56,267);
        ParedV paredV98 = new ParedV();
        addObject(paredV98,56,229);
        ParedV paredV99 = new ParedV();
        addObject(paredV99,56,195);
        ParedV paredV100 = new ParedV();
        addObject(paredV100,56,159);
        ParedV paredV101 = new ParedV();
        addObject(paredV101,56,115);
        paredH7.setLocation(437,782);
        paredH7.setLocation(437,789);
        paredH3.setLocation(624,787);
        paredH2.setLocation(660,781);
        paredH6.setLocation(505,788);
        paredH.setLocation(691,779);

        Car1 car1 = new Car1();
        addObject(car1,525,816);
    }
    
    public void act()
    {
        myScoreBoard.update("Vueltas: "+Car.vScore);
        myHealth.update("Vida: "+Car.Health+"hp");
        OpScoreBoard.update("Vueltas: "+Car1.vScore);
        OpHealth.update("Vida: "+Car1.Health+"hp");
        BlueWin();
        RedWin();
        Blueloose();
        Redloose();
        Draw();
    }
    public void BlueWin()
    {
        if (Car.vScore == 3)
        {
            addObject(new Bluewin(), 450, 450);
            Car.vScore = 0;
            Car1.vScore = 0;
            Car.Health = 100;
            Car1.Health = 100;
            BothCars = 0;
            Greenfoot.stop();
        }
    }
    public void RedWin()
    {
        if (Car1.vScore == 3)
        {
            addObject(new Redwin(), 450, 450);
            Car1.vScore = 0;
            Car.vScore = 0;
            Car1.Health = 100;
            Car.Health = 100;
            BothCars = 0;
            Greenfoot.stop();
        }
    }
    public void Redloose()
    {
        if (Car1.Health <= 0)
        {
            addObject(new Redloose(), 450, 675);
            Car1.vScore = 0;
            Car1.Health = 100;
            removeObjects(getObjects(Car1.class));
            BothCars = BothCars + 1;
        }
    }
    public void Blueloose()
    {
        if (Car.Health <= 0)
        {
            addObject(new Blueloose(), 450, 675);
            Car.vScore = 0;
            Car.Health = 100;
            removeObjects(getObjects(Car.class));
            BothCars = BothCars + 1;
            BothCars = BothCars + 1;
        }
    }
    public void Draw()
    {
        if (BothCars >= 2)
        {
            addObject(new Draw(), 450, 450);
            Car1.vScore = 0;
            Car.vScore = 0;
            Car1.Health = 100;
            Car.Health = 100;
            BothCars = 0;
            Greenfoot.stop();
        }
    }
    }

