import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class Car1 extends Actor
{
    /**
     * Act - do whatever the Crab wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        moveAndTurn();
        punto();
        paredH();
        paredV();
        Kid();
        Police();
        Pit();
    }
    
    public static int vScore = 0;
    public static int Health = 100;
    
    
    public void moveAndTurn()
    {
        
        if(Greenfoot.isKeyDown("up"))
        {
            move(4);
        }
        if(Greenfoot.isKeyDown("down"))
        {
            move(-4);
        }
        if (Greenfoot.isKeyDown("left"))
        {
            turn(-3);
        }
        if (Greenfoot.isKeyDown("right"))
        {
            turn(3);
        }
    }
    
    public void punto()
    {
        if (getX() >= 480 && getX() <= 482 && getY() >= 778 && getY() <= 892)
        {
            vScore = vScore + 1;
            
        }
    }   
    public void paredH()
    {
        Actor paredH;
        paredH = getOneObjectAtOffset(0, 0, ParedH.class);
        if (paredH != null)
        {
            World world;
            world = getWorld();
            Health = Health - 1;
        }
    } 
    public void paredV()
    {
        Actor paredV;
        paredV = getOneObjectAtOffset(0, 0, ParedV.class);
        if (paredV != null)
        {
            World world;
            world = getWorld();
            Health = Health - 1;
        }
    } 
    public void Kid()
    {
        Actor kid;
        kid = getOneObjectAtOffset(0, 0, Kid.class);
        if (kid != null)
        {
            World world;
            world = getWorld();
            Health = Health - 2;
        }
    } 
    public void Police()
    {
        Actor police;
        police = getOneObjectAtOffset(0, 0, Police.class);
        if (police != null)
        {
            World world;
            world = getWorld();
            Health = Health - 3;
        }
    }
    public void Pit()
    {
        if (getX() >= 250 && getX() <= 355 && getY() >= 730 && getY() <= 785)
        {
            Health = Health + 1;;
            
        }
    }  
}
