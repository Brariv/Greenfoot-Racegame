import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.*; //colors

/**
 * Write a description of class Player here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player extends Actor
{
    public Player(String text)
    {
        GreenfootImage Players = new GreenfootImage(text.length()*20, 30);
        Players.setColor(greenfoot.Color.WHITE);
        Players.drawString(text, 2, 20);
        setImage(Players);
    }
    
    public void update(String text)
    {
     GreenfootImage Players = getImage();
     Players.clear();
     Players.drawString(text, 2, 20);
    }
}

