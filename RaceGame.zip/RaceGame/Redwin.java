import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Redwin here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Redwin extends Actor
{
    /**
     * Act - do whatever the Redwin wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Redwin()
    {
        setImage(new GreenfootImage("Victoria Roja!", 80, Color.RED, Color.WHITE));
    }
    public void act()
    {
        // Add your action code here.
    }
}
