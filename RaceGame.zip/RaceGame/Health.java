import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.*; //colors

/**
 * Write a description of class Health here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Health extends Actor
{
    public Health(String text)
    {
        GreenfootImage myHealth = new GreenfootImage(text.length()*20, 30);
        myHealth.setColor(greenfoot.Color.WHITE);
        myHealth.drawString(text, 2, 20);
        setImage(myHealth);
    }
    
    public void update(String text)
    {
     GreenfootImage myHealth = getImage();
     myHealth.clear();
     myHealth.drawString(text, 2, 20);
    }
}

