import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Redloose here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Redloose extends Actor
{
    /**
     * Act - do whatever the Redloose wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Redloose()
    {
        setImage(new GreenfootImage("Jugador Rojo Eliminado", 40, Color.RED, Color.BLACK));
    }
    public void act()
    {
        // Add your action code here.
    }
}
